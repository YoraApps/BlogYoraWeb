<?php
  $link=mysql_connect('localhost','yoratech_admin','Yora@335');
  mysql_select_db('yoratech_angluar_blog',$link);
 
?>
